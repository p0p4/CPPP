Optimointikalvot & osa teht�vist�:
Lauri Viitanen
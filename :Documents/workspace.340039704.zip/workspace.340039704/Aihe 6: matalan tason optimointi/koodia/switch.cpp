// Type your code here, or load an example.
int square(int num) {
    
    int retval = 0;

    switch (num)
    {
        case 1:
            retval = 1;
            break;
        case 2:
            retval = 4;
            break;
        case 3:
            retval = 9;
            break;
        case 4:
            retval = 16;
            break;
        case 5:
            retval = 25;
            break;
        case 6:
            retval = 36;
            break;
        case 7:
            retval = 49;
            break;
        case 8:
          retval = 64;
            break;
        case 9:
            retval = 81;
            break;
        default:
            retval = 0;
            break;
    }

    return retval;
}
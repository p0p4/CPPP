// Type your code here, or load an example.
int square(int num) {
    
    int retval = 0;

    if (num == 1)
        retval = 1;
    else if (num == 2)
        retval = 4;
    else if (num == 3)
        retval = 9;
    else if (num == 4)
        retval = 16;
    else if (num == 5)
        retval = 25;
    else if (num == 6)
        retval = 36;
    else if (num == 7)
        retval = 49;
    else if (num == 8)
        retval = 64;
    else if (num == 9)
        retval = 81;
    else
        retval = 0;

    return retval;
}

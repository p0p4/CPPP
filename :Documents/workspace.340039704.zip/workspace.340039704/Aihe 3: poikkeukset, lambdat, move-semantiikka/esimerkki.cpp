#include <cstring>
#include <iostream>
using namespace std;

class Big_Data
{
public:

	Big_Data(unsigned sz)
	{
		_p = malloc(sz);
		_sz = sz;
	}

	~Big_Data()
	{
		free(_p);
	}

	// Sijoitusoperaattori
	Big_Data& operator= (const Big_Data& rhs)
	{
		// Sijoitus itseen? Ei tehd� mit��n.
		if (this == &rhs)
			return *this;

		free(_p);
		_p = malloc(rhs._sz);
		_sz = rhs._sz;
		memcpy(_p, rhs._p, _sz);

		return *this;
	}

	Big_Data& operator= (Big_Data&& rhs)
	{
		free(_p);

		// varastaminen
		_p = rhs._p;
		_sz = rhs._sz;

		// "resetointi"
		rhs._p = nullptr;

		return *this;
	}

	// Kopio-ctor
	Big_Data(const Big_Data& orig)
	{
		_p = malloc(orig._sz);
		_sz = orig._sz;
		memcpy(_p, orig._p, _sz);
	}

private:

	void* _p;
	unsigned _sz;
};

int main()
{
	Big_Data a(1024);
	Big_Data b(2048);
	a = b;

	Big_Data c(1024);
	c = Big_Data(1024);
	return 0;
}